#include<iostream>
using namespace std;


int main(){

int n;
cout<<"Please enter the size of the array:";
cin>>n;
int *a=new int[n];


return 0;
}
