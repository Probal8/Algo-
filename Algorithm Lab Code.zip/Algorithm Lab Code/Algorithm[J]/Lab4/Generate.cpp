#include<bits/stdc++.h>
using namespace std;
/*
1. Selection vs Quick Sort
2. Insertion vs MergeSort
3. Bubble vs QuickSort


*/

int main(){
    srand(time(0));
    int n=100000;
    ofstream fout("1000k.txt");
    for(int i=0;i<n;i++){
        fout<<rand()<<endl;
    }


return 0;
}

