#include<bits/stdc++.h>
using namespace std;
/*
1. Selection vs Quick Sort
2. Insertion vs MergeSort
3. Bubble vs QuickSort


*/

int main(){

      cout<<(34563%3)+1<<endl;


return 0;
}
