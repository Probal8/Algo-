#include<bits/stdc++.h>
using namespace std;

int main(){
char str[] = "Copa America"; cout << strlen(str);


return 0;
}


